import os
import time
import threading
import subprocess
import pytchat
from websocket_server import WebsocketServer

# ============================================================
# CONFIG
# ============================================================

YOUTUBE_VIDEO_ID = None
VM_NAME = None

# ============================================================
# SUBPROCESS HELPERS
# ============================================================

_SUBPROCESS_FLAGS = 0
try:
    _SUBPROCESS_FLAGS = subprocess.CREATE_NO_WINDOW
except:
    pass

def _run(*args, **kwargs):
    kwargs.setdefault("creationflags", _SUBPROCESS_FLAGS)
    return subprocess.run(*args, **kwargs)

def _popen(*args, **kwargs):
    kwargs.setdefault("creationflags", _SUBPROCESS_FLAGS)
    return subprocess.Popen(*args, **kwargs)

# ============================================================
# SPEECH SYNTHESIS
# ============================================================

def _speak(text):
    if not text:
        return

    safe = text.replace("'", "''")

    ps_cmd = f"""
Add-Type -AssemblyName System.Speech;
$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;
$s.Speak('{safe}');
"""

    try:
        subprocess.Popen(
            ["powershell","-NoLogo","-NoProfile","-WindowStyle","Hidden","-Command",ps_cmd],
            creationflags=_SUBPROCESS_FLAGS,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except:
        pass

def log(msg):
    print(f"[LOG] {msg}")
    _speak(msg)
    chat_broadcast(f"[SUCCESS] {msg}")

def log_warn(msg):
    print(f"[WARN] {msg}")
    _speak(f"Warning: {msg}")
    chat_broadcast(f"[WARN] {msg}")

def log_err(msg):
    print(f"[ERR] {msg}")
    _speak(f"Error: {msg}")
    chat_broadcast(f"[FAIL] {msg}")

# ============================================================
# VBOXMANAGE LOCATOR
# ============================================================

def find_vboxmanage():
    paths = [
        r"C:\Program Files\Oracle\VirtualBox\VBoxManage.exe",
        r"C:\Program Files (x86)\Oracle\VirtualBox\VBoxManage.exe",
    ]
    for p in paths:
        if os.path.isfile(p):
            return p
    return "VBoxManage"

VBOXMANAGE = find_vboxmanage()

# ============================================================
# BLOCKED WORDS
# ============================================================

BLOCKED_WORDS = {"rmdir", "rd", "shutdown"}

def contains_blocked_words(text):
    return any(b in text.lower() for b in BLOCKED_WORDS)

# ============================================================
# SCANCODE ENGINE
# ============================================================

SCANCODES = {
    "a":0x1E,"b":0x30,"c":0x2E,"d":0x20,"e":0x12,"f":0x21,"g":0x22,"h":0x23,
    "i":0x17,"j":0x24,"k":0x25,"l":0x26,"m":0x32,"n":0x31,"o":0x18,"p":0x19,
    "q":0x10,"r":0x13,"s":0x1F,"t":0x14,"u":0x16,"v":0x2F,"w":0x11,"x":0x2D,
    "y":0x15,"z":0x2C,
    "0":0x0B,"1":0x02,"2":0x03,"3":0x04,"4":0x05,"5":0x06,"6":0x07,"7":0x08,"8":0x09,"9":0x0A,
    "enter":0x1C,"space":0x39,"tab":0x0F,"backspace":0x0E,"escape":0x01,"esc":0x01,
    "minus":0x0C,"equals":0x0D,"comma":0x33,"period":0x34,"slash":0x35,
    "up":0x48,"down":0x50,"left":0x4B,"right":0x4D,
    "ctrl":0x1D,"alt":0x38,"shift":0x2A,"win":0x5B
}

EXTENDED = {"up","down","left","right","win"}

def send_scancodes(byte_list):
    if not VM_NAME:
        return False
    hex_args = [f"{b:02x}" for b in byte_list]
    try:
        _popen([VBOXMANAGE,"controlvm",VM_NAME,"keyboardputscancode"]+hex_args,
               stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        return True
    except:
        return False

def send_key(key):
    key = key.lower().strip()
    if key not in SCANCODES:
        log_err(f"Unknown key: {key}")
        return False
    scan = SCANCODES[key]
    ext = key in EXTENDED
    seq = []
    if ext: seq.append(0xE0)
    seq.append(scan)
    if ext: seq.append(0xE0)
    seq.append(scan|0x80)
    log(f"key {key}")
    return send_scancodes(seq)

def send_keydown(key):
    key = key.lower().strip()
    if key not in SCANCODES:
        return False
    scan = SCANCODES[key]
    ext = key in EXTENDED
    seq = ([0xE0] if ext else []) + [scan]
    log(f"keydown {key}")
    return send_scancodes(seq)

def send_keyup(key):
    key = key.lower().strip()
    if key not in SCANCODES:
        return False
    scan = SCANCODES[key]
    ext = key in EXTENDED
    seq = ([0xE0] if ext else []) + [scan|0x80]
    log(f"keyup {key}")
    return send_scancodes(seq)

def send_combo(keys):
    down=[]
    up=[]
    for k in keys:
        k=k.lower().strip()
        if k not in SCANCODES:
            continue
        scan=SCANCODES[k]
        ext=k in EXTENDED
        if ext: down.append(0xE0)
        down.append(scan)
        if ext: up.append(0xE0)
        up.append(scan|0x80)
    log(f"combo {'+'.join(keys)}")
    return send_scancodes(down+up)

def type_text(text):
    if contains_blocked_words(text):
        log_err("Blocked word detected")
        return False
    log(f"type {text}")
    try:
        _run([VBOXMANAGE,"controlvm",VM_NAME,"keyboardputstring",text],
             capture_output=True,timeout=10)
        return True
    except:
        return False

# ============================================================
# VM CONTROL (INCLUDING NEW REVERT PATCH)
# ============================================================

def shutdownforrevert():
    log("Preparing VM for revert (shutdown for revert)")
    time.sleep(5)

    _run([VBOXMANAGE, "controlvm", VM_NAME, "savestate"], capture_output=True)
    log("VM saved state for revert")

    time.sleep(5)

def startvmforrevert():
    log("Starting VM after revert")
    _run([VBOXMANAGE, "startvm", VM_NAME, "--type", "gui"], capture_output=True)

def revert_vm():
    log("Reverting VM (custom revert sequence)")

    shutdownforrevert()

    log("Restoring latest snapshot")
    _run([VBOXMANAGE, "snapshot", VM_NAME, "restorecurrent"], capture_output=True)

    startvmforrevert()

def start_vm():
    log("Starting VM")
    _run([VBOXMANAGE,"startvm",VM_NAME,"--type","gui"],capture_output=True)

def restart_vm():
    log("Restarting VM")
    _run([VBOXMANAGE,"controlvm",VM_NAME,"acpipowerbutton"],capture_output=True)
    time.sleep(5)
    _run([VBOXMANAGE,"controlvm",VM_NAME,"poweroff"],capture_output=True)
    start_vm()

# ============================================================
# MOUSE ENGINE
# ============================================================

def mouse_move(dx,dy):
    log(f"move {dx},{dy}")
    _run([VBOXMANAGE,"controlvm",VM_NAME,"mousemove",str(dx),str(dy),"--relative"])

def mouse_abs(x,y):
    log(f"abs {x},{y}")
    _run([VBOXMANAGE,"controlvm",VM_NAME,"mousemove",str(x),str(y)])

def mouse_click(button="left"):
    log(f"click {button}")
    mask={"left":1,"right":2,"middle":4}[button]
    _run([VBOXMANAGE,"controlvm",VM_NAME,"mousebutton","down",str(mask)])
    _run([VBOXMANAGE,"controlvm",VM_NAME,"mousebutton","up",str(mask)])

# ============================================================
# CHAIN ENGINE
# ============================================================

def parse_chain(raw):
    parts=raw.strip().split()
    cmds=[]
    cur=[]
    for p in parts:
        if p.startswith("!"):
            if cur: cmds.append(cur)
            cur=[p]
        else:
            cur.append(p)
    if cur: cmds.append(cur)
    return cmds

def validate_chain(cmds):
    if not cmds: return False,"Empty"
    if cmds[0][0]=="!wait": return False,"Starts with wait"
    if cmds[-1][0]=="!wait": return False,"Ends with wait"

    waits=0
    total=0
    for i,c in enumerate(cmds):
        name=c[0]
        if any(contains_blocked_words(x) for x in c):
            return False,"Blocked word"
        if name=="!wait":
            waits+=1
            if waits>3: return False,"Too many waits"
            if i>0 and cmds[i-1][0]=="!wait": return False,"Adjacent waits"
            try: t=float(c[1])
            except: return False,"Invalid wait"
            if not(0.1<=t<=5): return False,"Wait out of range"
            total+=t
            if total>20: return False,"Total wait >20"
    return True,""

def execute_chain(user,raw):
    cmds=parse_chain(raw)
    ok,reason=validate_chain(cmds)
    if not ok:
        log_err(f"Chain rejected: {reason}")
        return

    log(f"{user} chain: {raw}")

    for c in cmds:
        name=c[0]
        args=c[1:]

        if name=="!wait":
            time.sleep(float(args[0]))
            continue

        elif name=="!startvm":
            time.sleep(5)
            start_vm()

        elif name=="!revert":
            time.sleep(5)
            revert_vm()

        elif name=="!restartvm":
            time.sleep(5)
            restart_vm()

        elif name=="!type":
            time.sleep(5)
            type_text(" ".join(args))

        elif name in ("!send","!typeenter"):
            text=" ".join(args)
            time.sleep(5)
            type_text(text)
            time.sleep(5)
            send_key("enter")

        elif name=="!key":
            time.sleep(5)
            send_key(args[0])

        elif name=="!keydown":
            time.sleep(5)
            send_keydown(args[0])

        elif name=="!keyup":
            time.sleep(5)
            send_keyup(args[0])

        elif name=="!combo":
            if "+" in " ".join(args):
                keys=[k.strip() for k in " ".join(args).split("+")]
            else:
                keys=args
            time.sleep(5)
            send_combo(keys)

        elif name=="!move":
            dx,dy=int(args[0]),int(args[1])
            time.sleep(5)
            mouse_move(dx,dy)

        elif name=="!abs":
            x,y=int(args[0]),int(args[1])
            time.sleep(5)
            mouse_abs(x,y)

        elif name in ("!click","!lclick"):
            time.sleep(5)
            mouse_click("left")

        elif name in ("!rclick","!rightclick"):
            time.sleep(5)
            mouse_click("right")

        elif name in ("!mclick","!middleclick"):
            time.sleep(5)
            mouse_click("middle")

# ============================================================
# WEBSOCKET SERVER (PORT 9001)
# ============================================================

chat_clients = []
chat_server = None

def chat_broadcast(msg):
    if not chat_server:
        return
    for c in list(chat_clients):
        try:
            chat_server.send_message(c, msg)
        except:
            pass

def chat_new_client(client, server):
    chat_clients.append(client)
    chat_broadcast("[SUCCESS] Overlay Connected")

def chat_client_left(client, server):
    if client in chat_clients:
        chat_clients.remove(client)
    chat_broadcast("[WARN] Overlay Disconnected")

def chat_message_received(client, server, message):
    pass

def start_chat_ws():
    global chat_server
    while True:
        try:
            chat_server = WebsocketServer(
                host="0.0.0.0",
                port=9001,
                loglevel=0
            )
            chat_server.set_fn_new_client(chat_new_client)
            chat_server.set_fn_client_left(chat_client_left)
            chat_server.set_fn_message_received(chat_message_received)

            log("[SUCCESS] WebSocket server running on port 9001")
            chat_server.run_forever()

        except:
            log_err("WebSocket server crashed. Reconnecting...")
            time.sleep(2)
            continue

# ============================================================
# MESSAGE HANDLER
# ============================================================

def handle_message(user, msg):
    if not msg.startswith("!"):
        chat_broadcast(f"@{user}: {msg}")
        return

    execute_chain(user, msg)

# ============================================================
# YOUTUBE CHAT LOOP (WITH RECONNECT)
# ============================================================

def chat_loop():
    global YOUTUBE_VIDEO_ID

    if not YOUTUBE_VIDEO_ID:
        YOUTUBE_VIDEO_ID = input("Enter YouTube live video ID: ").strip()

    while True:
        try:
            log("[SUCCESS] Bot connected.")
            chat = pytchat.create(video_id=YOUTUBE_VIDEO_ID)

            while chat.is_alive():
                for c in chat.get().sync_items():
                    user = c.author.name
                    msg = c.message

                    print(f"[{user}] {msg}")
                    chat_broadcast(f"@{user}: {msg}")

                    handle_message(user, msg)

        except Exception as e:
            import traceback
            traceback.print_exc()

            log_err(f"Bot disconnected: {e}")
            time.sleep(2)
            continue

# ============================================================
# MAIN
# ============================================================

def main():
    global VM_NAME
    VM_NAME = input("Enter VirtualBox VM name: ").strip()
    log(f"Using VM: {VM_NAME}")

    t_chat = threading.Thread(target=start_chat_ws, daemon=True)
    t_chat.start()

    chat_loop()

if __name__ == "__main__":
    main()