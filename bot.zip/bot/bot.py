import os
import time
import threading
import subprocess
from queue import Queue

import pytchat
from websocket_server import WebsocketServer

# ============================================================
# CONFIG
# ============================================================

YOUTUBE_VIDEO_ID = None
VM_NAME = None

API_KEY = ""          # (optional) YouTube Data API key if you later add real mod detection
MODS = set()          # static mod list, e.g. {"MrTristin-449"}

# ============================================================
# SUBPROCESS HELPERS
# ============================================================

_SUBPROCESS_FLAGS = 0
try:
    _SUBPROCESS_FLAGS = subprocess.CREATE_NO_WINDOW
except:
    pass

def _run(*args, **kwargs):
    kwargs.setdefault("creationflags", _SUBPROCESS_FLAGS)
    return subprocess.run(*args, **kwargs)

def _popen(*args, **kwargs):
    kwargs.setdefault("creationflags", _SUBPROCESS_FLAGS)
    return subprocess.Popen(*args, **kwargs)

# ============================================================
# SPEECH QUEUE (S1: ONE AT A TIME)
# ============================================================

speech_queue = Queue()
speech_thread_started = False

def _speech_worker():
    while True:
        text = speech_queue.get()
        if not text:
            speech_queue.task_done()
            continue

        safe = text.replace("'", "''")
        ps_cmd = f"""
Add-Type -AssemblyName System.Speech;
$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;
$s.Speak('{safe}');
"""
        try:
            p = subprocess.Popen(
                ["powershell","-NoLogo","-NoProfile","-WindowStyle","Hidden","-Command",ps_cmd],
                creationflags=_SUBPROCESS_FLAGS,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            p.wait()
        except:
            pass

        speech_queue.task_done()

def _ensure_speech_thread():
    global speech_thread_started
    if not speech_thread_started:
        t = threading.Thread(target=_speech_worker, daemon=True)
        t.start()
        speech_thread_started = True

def _speak(text):
    if not text:
        return
    _ensure_speech_thread()
    speech_queue.put(text)

# ============================================================
# LOGGING
# ============================================================

def log(msg):
    print(f"[LOG] {msg}")
    _speak(msg)
    chat_broadcast(f"[SUCCESS] {msg}")

def log_warn(msg):
    print(f"[WARN] {msg}")
    _speak(f"Warning: {msg}")
    chat_broadcast(f"[WARN] {msg}")

def log_err(msg):
    print(f"[ERR] {msg}")
    _speak(f"Error: {msg}")
    chat_broadcast(f"[FAIL] {msg}")

# ============================================================
# VBOXMANAGE LOCATOR
# ============================================================

def find_vboxmanage():
    paths = [
        r"C:\Program Files\Oracle\VirtualBox\VBoxManage.exe",
        r"C:\Program Files (x86)\Oracle\VirtualBox\VBoxManage.exe",
    ]
    for p in paths:
        if os.path.isfile(p):
            return p
    return "VBoxManage"

VBOXMANAGE = find_vboxmanage()

# ============================================================
# BLOCKED WORDS
# ============================================================

BLOCKED_WORDS = {"rmdir", "rd", "shutdown"}

def contains_blocked_words(text):
    return any(b in text.lower() for b in BLOCKED_WORDS)

# ============================================================
# SCANCODE ENGINE (ALL MAIN KEYS + F1–F24)
# ============================================================

SCANCODES = {
    "a":0x1E,"b":0x30,"c":0x2E,"d":0x20,"e":0x12,"f":0x21,"g":0x22,"h":0x23,
    "i":0x17,"j":0x24,"k":0x25,"l":0x26,"m":0x32,"n":0x31,"o":0x18,"p":0x19,
    "q":0x10,"r":0x13,"s":0x1F,"t":0x14,"u":0x16,"v":0x2F,"w":0x11,"x":0x2D,
    "y":0x15,"z":0x2C,

    "0":0x0B,"1":0x02,"2":0x03,"3":0x04,"4":0x05,
    "5":0x06,"6":0x07,"7":0x08,"8":0x09,"9":0x0A,

    "enter":0x1C,"space":0x39,"tab":0x0F,"backspace":0x0E,
    "escape":0x01,"esc":0x01,

    "minus":0x0C,"equals":0x0D,
    "comma":0x33,"period":0x34,"slash":0x35,
    "semicolon":0x27,"quote":0x28,"apostrophe":0x28,
    "backtick":0x29,"grave":0x29,
    "lbracket":0x1A,"rbracket":0x1B,"backslash":0x2B,

    "capslock":0x3A,
    "leftshift":0x2A,"rightshift":0x36,
    "leftctrl":0x1D,"rightctrl":0x1D,
    "leftalt":0x38,"rightalt":0x38,
    "ctrl":0x1D,"alt":0x38,"shift":0x2A,"win":0x5B,

    "up":0x48,"down":0x50,"left":0x4B,"right":0x4D,
    "insert":0x52,"delete":0x53,"home":0x47,"end":0x4F,
    "pageup":0x49,"pagedown":0x51,

    "numlock":0x45,"scrolllock":0x46,
    "numpad0":0x52,"numpad1":0x4F,"numpad2":0x50,"numpad3":0x51,
    "numpad4":0x4B,"numpad5":0x4C,"numpad6":0x4D,
    "numpad7":0x47,"numpad8":0x48,"numpad9":0x49,
    "numpadplus":0x4E,"numpadminus":0x4A,
    "numpadmul":0x37,"numpaddiv":0x35,"numpadenter":0x1C,

    "printscreen":0x37,"pause":0x45,
}

SCANCODES.update({
    "f1":0x3B,"f2":0x3C,"f3":0x3D,"f4":0x3E,
    "f5":0x3F,"f6":0x40,"f7":0x41,"f8":0x42,
    "f9":0x43,"f10":0x44,"f11":0x57,"f12":0x58,

    "f13":0x64,"f14":0x65,"f15":0x66,"f16":0x67,
    "f17":0x68,"f18":0x69,"f19":0x6A,"f20":0x6B,
    "f21":0x6C,"f22":0x6D,"f23":0x6E,"f24":0x76
})

EXTENDED = {
    "up","down","left","right",
    "insert","delete","home","end","pageup","pagedown",
    "rightctrl","rightalt","win"
}

def send_scancodes(byte_list):
    if not VM_NAME:
        return False
    hex_args = [f"{b:02x}" for b in byte_list]
    try:
        _popen(
            [VBOXMANAGE,"controlvm",VM_NAME,"keyboardputscancode"]+hex_args,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        return True
    except:
        return False

def send_key(key):
    key = key.lower().strip()
    if key not in SCANCODES:
        log_err(f"Unknown key: {key}")
        return False
    scan = SCANCODES[key]
    ext = key in EXTENDED
    seq = []
    if ext: seq.append(0xE0)
    seq.append(scan)
    if ext: seq.append(0xE0)
    seq.append(scan|0x80)
    log(f"key {key}")
    return send_scancodes(seq)

def send_keydown(key):
    key = key.lower().strip()
    if key not in SCANCODES:
        return False
    scan = SCANCODES[key]
    ext = key in EXTENDED
    seq = ([0xE0] if ext else []) + [scan]
    log(f"keydown {key}")
    return send_scancodes(seq)

def send_keyup(key):
    key = key.lower().strip()
    if key not in SCANCODES:
        return False
    scan = SCANCODES[key]
    ext = key in EXTENDED
    seq = ([0xE0] if ext else []) + [scan|0x80]
    log(f"keyup {key}")
    return send_scancodes(seq)

def send_combo(keys):
    down=[]
    up=[]
    for k in keys:
        k=k.lower().strip()
        if k not in SCANCODES:
            continue
        scan=SCANCODES[k]
        ext=k in EXTENDED
        if ext: down.append(0xE0)
        down.append(scan)
        if ext: up.append(0xE0)
        up.append(scan|0x80)
    log(f"combo {'+'.join(keys)}")
    return send_scancodes(down+up)

def type_text(text):
    if contains_blocked_words(text):
        log_err("Blocked word detected")
        return False
    log(f"type {text}")
    try:
        _run(
            [VBOXMANAGE,"controlvm",VM_NAME,"keyboardputstring",text],
            capture_output=True,
            timeout=10
        )
        return True
    except:
        return False

# ============================================================
# REAL PS/2 MOUSE SCANCODES
# ============================================================

mouse_x = 0
mouse_y = 0

def send_mouse_packet(dx, dy):
    dx = max(-128, min(127, dx))
    dy = max(-128, min(127, dy))

    dy = -dy

    sx = 1 if dx < 0 else 0
    sy = 1 if dy < 0 else 0

    b1 = 0x08 | (sx << 4) | (sy << 5)
    b2 = dx & 0xFF
    b3 = dy & 0xFF

    send_scancodes([b1, b2, b3])

def mouse_move(dx, dy):
    log(f"move {dx},{dy}")
    send_mouse_packet(dx, dy)

def mouse_abs(x, y):
    global mouse_x, mouse_y
    dx = x - mouse_x
    dy = y - mouse_y
    mouse_x = x
    mouse_y = y
    log(f"abs {x},{y}")
    send_mouse_packet(dx, dy)

def mouse_button(left=False, right=False, middle=False):
    b1 = 0x08
    if left: b1 |= 0x01
    if right: b1 |= 0x02
    if middle: b1 |= 0x04
    send_scancodes([b1, 0x00, 0x00])

def mouse_click(button="left"):
    log(f"click {button}")
    if button == "left":
        mouse_button(left=True)
        mouse_button(left=False)
    elif button == "right":
        mouse_button(right=True)
        mouse_button(right=False)
    elif button == "middle":
        mouse_button(middle=True)
        mouse_button(middle=False)

# ============================================================
# VM CONTROL (REVERT + WIFI)
# ============================================================

def shutdownforrevert():
    log("Preparing VM for revert (shutdown for revert)")
    time.sleep(5)

    _run([VBOXMANAGE, "controlvm", VM_NAME, "savestate"], capture_output=True)
    log("VM saved state for revert")

    time.sleep(5)

def startvmforrevert():
    log("Starting VM after revert")
    _run([VBOXMANAGE, "startvm", VM_NAME, "--type", "gui"], capture_output=True)

def revert_vm():
    log("Reverting VM (custom revert sequence)")

    shutdownforrevert()

    log("Restoring latest snapshot")
    _run([VBOXMANAGE, "snapshot", VM_NAME, "restorecurrent"], capture_output=True)

    startvmforrevert()

def start_vm():
    log("Starting VM")
    _run([VBOXMANAGE,"startvm",VM_NAME,"--type","gui"],capture_output=True)

def restart_vm():
    log("Restarting VM")
    _run([VBOXMANAGE,"controlvm",VM_NAME,"acpipowerbutton"],capture_output=True)
    time.sleep(5)
    _run([VBOXMANAGE,"controlvm",VM_NAME,"poweroff"],capture_output=True)
    start_vm()

def wifi_off():
    log("Turning VM network cable OFF")
    _run([VBOXMANAGE,"controlvm",VM_NAME,"nic1","cableconnected","off"],capture_output=True)

def wifi_on():
    log("Turning VM network cable ON")
    _run([VBOXMANAGE,"controlvm",VM_NAME,"nic1","cableconnected","on"],capture_output=True)

# ============================================================
# MOD DETECTION (STATIC LIST FOR NOW)
# ============================================================

def is_mod(user):
    # Extend later with real YouTube API + urllib if you want.
    return user in MODS

# ============================================================
# CHAIN ENGINE
# ============================================================

def parse_chain(raw):
    parts=raw.strip().split()
    cmds=[]
    cur=[]
    for p in parts:
        if p.startswith("!"):
            if cur: cmds.append(cur)
            cur=[p]
        else:
            cur.append(p)
    if cur: cmds.append(cur)
    return cmds

def validate_chain(cmds):
    if not cmds: return False,"Empty"
    if cmds[0][0]=="!wait": return False,"Starts with wait"
    if cmds[-1][0]=="!wait": return False,"Ends with wait"

    waits=0
    total=0
    for i,c in enumerate(cmds):
        name=c[0]
        if any(contains_blocked_words(x) for x in c):
            return False,"Blocked word"
        if name=="!wait":
            waits+=1
            if waits>3: return False,"Too many waits"
            if i>0 and cmds[i-1][0]=="!wait": return False,"Adjacent waits"
            try: t=float(c[1])
            except: return False,"Invalid wait"
            if not(0.1<=t<=5): return False,"Wait out of range"
            total+=t
            if total>20: return False,"Total wait >20"
    return True,""

def execute_chain_inner(user,raw):
    cmds=parse_chain(raw)
    ok,reason=validate_chain(cmds)
    if not ok:
        log_err(f"Chain rejected: {reason}")
        return

    log(f"{user} chain: {raw}")

    for c in cmds:
        name=c[0]
        args=c[1:]

        if name=="!wait":
            time.sleep(float(args[0]))
            continue

        elif name=="!startvm":
            start_vm()

        elif name=="!revert":
            revert_vm()

        elif name=="!restartvm":
            restart_vm()

        elif name=="!wifioff_internal":
            wifi_off()

        elif name=="!wifion_internal":
            wifi_on()

        elif name=="!type":
            time.sleep(5)
            type_text(" ".join(args))

        elif name in ("!send","!typeenter"):
            text=" ".join(args)
            time.sleep(5)
            type_text(text)
            time.sleep(5)
            send_key("enter")

        elif name=="!key":
            time.sleep(5)
            send_key(args[0])

        elif name=="!keydown":
            time.sleep(5)
            send_keydown(args[0])

        elif name=="!keyup":
            time.sleep(5)
            send_keyup(args[0])

        elif name=="!combo":
            if "+" in " ".join(args):
                keys=[k.strip() for k in " ".join(args).split("+")]
            else:
                keys=args
            time.sleep(5)
            send_combo(keys)

        elif name=="!move":
            dx,dy=int(args[0]),int(args[1])
            mouse_move(dx,dy)

        elif name=="!abs":
            x,y=int(args[0]),int(args[1])
            mouse_abs(x,y)

        elif name in ("!click","!lclick"):
            mouse_click("left")

        elif name in ("!rclick","!rightclick"):
            mouse_click("right")

        elif name in ("!mclick","!middleclick"):
            mouse_click("middle")

# ============================================================
# VOTE SYSTEM (B2-B)
# ============================================================

votes = {
    "restartvm": 0,
    "revert": 0
}
VOTE_REQUIRED = 2

vote_queues = {
    "restartvm": [],
    "revert": []
}

def vote_status():
    chat_broadcast(f"[WARN] RestartVM Votes: {votes['restartvm']}/{VOTE_REQUIRED}")
    chat_broadcast(f"[WARN] Revert Votes: {votes['revert']}/{VOTE_REQUIRED}")

def process_chain_with_votes(user, raw):
    cmds = parse_chain(raw)
    ok, reason = validate_chain(cmds)
    if not ok:
        log_err(f"Chain rejected: {reason}")
        return

    has_vm = False

    for c in cmds:
        name = c[0].lower()
        if name == "!restartvm":
            votes["restartvm"] += 1
            vote_queues["restartvm"].append((user, raw))
            chat_broadcast(f"[WARN] @{user} voted to restart VM ({votes['restartvm']}/{VOTE_REQUIRED})")
            has_vm = True
        elif name == "!revert":
            votes["revert"] += 1
            vote_queues["revert"].append((user, raw))
            chat_broadcast(f"[WARN] @{user} voted to revert VM ({votes['revert']}/{VOTE_REQUIRED})")
            has_vm = True

    if has_vm:
        vote_status()

        if votes["restartvm"] >= VOTE_REQUIRED:
            chat_broadcast("[SUCCESS] RestartVM vote passed!")
            for u, r in vote_queues["restartvm"]:
                execute_chain_inner(u, r)
            votes["restartvm"] = 0
            vote_queues["restartvm"].clear()

        if votes["revert"] >= VOTE_REQUIRED:
            chat_broadcast("[SUCCESS] Revert vote passed!")
            for u, r in vote_queues["revert"]:
                execute_chain_inner(u, r)
            votes["revert"] = 0
            vote_queues["revert"].clear()

        return

    execute_chain_inner(user, raw)

# ============================================================
# MACRO COMMANDS (!google, !gemini, !youtube)
# ============================================================

def build_google_chain(search):
    s = search.replace(" ", "+")
    return f"!key win !wait 5 !send supermium !wait 5 !send google.com/{s}"

def build_gemini_chain(quote):
    return f"!key win !wait 5 !send supermium !wait 5 !send gemini.google.com !wait 5 !send {quote}"

def build_youtube_chain(video_id):
    vid = video_id.strip()
    return f"!key win !wait 5 !send supermium !wait 5 !send youtu.be/{vid}"

# ============================================================
# MESSAGE HANDLER
# ============================================================

def handle_message(user,msg):
    if not msg.startswith("!"):
        chat_broadcast(f"@{user}: {msg}")
        return

    lower = msg.lower().strip()

    # !google [search]
    if lower.startswith("!google "):
        search = msg.split(" ", 1)[1]
        chain = build_google_chain(search)
        process_chain_with_votes(user, chain)
        return

    # !gemini [quote]
    if lower.startswith("!gemini "):
        quote = msg.split(" ", 1)[1]
        chain = build_gemini_chain(quote)
        process_chain_with_votes(user, chain)
        return

    # !youtube [videoid]
    if lower.startswith("!youtube "):
        video_id = msg.split(" ", 1)[1]
        chain = build_youtube_chain(video_id)
        process_chain_with_votes(user, chain)
        return

    # !wifioff (mod only)
    if lower == "!wifioff":
        if not is_mod(user):
            log_err(f"{user} tried !wifioff (mods only)")
            return
        chain = "!wifioff_internal"
        process_chain_with_votes(user, chain)
        return

    # !wifion (mod only)
    if lower == "!wifion":
        if not is_mod(user):
            log_err(f"{user} tried !wifion (mods only)")
            return
        chain = "!wifion_internal"
        process_chain_with_votes(user, chain)
        return

    # Normal commands
    process_chain_with_votes(user, msg)

# ============================================================
# WEBSOCKET SERVER (PORT 9001)
# ============================================================

chat_server = None

def chat_broadcast(msg):
    global chat_server
    if not chat_server:
        return
    try:
        chat_server.send_message_to_all(msg)
    except:
        pass

def chat_new_client(client, server):
    chat_broadcast("[SUCCESS] Overlay Connected")

def chat_client_left(client, server):
    chat_broadcast("[WARN] Overlay Disconnected")

def chat_message_received(client, server, message):
    pass

def start_chat_ws():
    global chat_server
    while True:
        try:
            chat_server = WebsocketServer(
                host="0.0.0.0",
                port=9001,
                loglevel=0
            )
            chat_server.set_fn_new_client(chat_new_client)
            chat_server.set_fn_client_left(chat_client_left)
            chat_server.set_fn_message_received(chat_message_received)

            log("[SUCCESS] WebSocket server running on port 9001")
            chat_server.run_forever()

        except:
            log_err("WebSocket server crashed. Reconnecting...")
            time.sleep(2)
            continue

# ============================================================
# YOUTUBE CHAT LOOP (WITH RECONNECT)
# ============================================================

def chat_loop():
    global YOUTUBE_VIDEO_ID

    if not YOUTUBE_VIDEO_ID:
        YOUTUBE_VIDEO_ID = input("Enter YouTube live video ID: ").strip()

    while True:
        try:
            log("[SUCCESS] Bot connected.")
            chat = pytchat.create(video_id=YOUTUBE_VIDEO_ID)

            while chat.is_alive():
                for c in chat.get().sync_items():
                    user = c.author.name
                    msg = c.message

                    print(f"[{user}] {msg}")
                    chat_broadcast(f"@{user}: {msg}")

                    handle_message(user, msg)

        except:
            log_err("Bot disconnected. Reconnecting...")
            time.sleep(2)
            continue

# ============================================================
# MAIN
# ============================================================

def main():
    global VM_NAME
    VM_NAME = input("Enter VirtualBox VM name: ").strip()
    log(f"Using VM: {VM_NAME}")

    t_chat = threading.Thread(target=start_chat_ws, daemon=True)
    t_chat.start()

    chat_loop()

if __name__ == "__main__":
    main()